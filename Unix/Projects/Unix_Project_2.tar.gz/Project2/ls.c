#include <sys/types.h>
#include <sys/dir.h>
#include <sys/param.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <dirent.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
#include <locale.h>
#include <langinfo.h>
#include <stdint.h>
#include <fcntl.h>
#include <string.h>

static char perms_buff[30];
const char *perms(mode_t mode);
static int tmp (const struct dirent *unused);
char pathname[MAXPATHLEN];

int main(int argc, char** argv)
{
    DIR *dir;
    int count,i,opt=0;
    struct direct *files1;
    struct direct **files;
    struct stat statbuf;
    char date[256];
    struct passwd pwent;
    struct passwd *pwentp;
    struct group grp;
    struct group *grpt;
    struct tm time;
    char buf[1024];


  if(argc==1){    //If there are no options used on command prompt
  
      dir = opendir (".");
      int x = 0;
      while((files1 = readdir(dir)) != NULL){
          if(!strcmp(files1->d_name, ".") || !strcmp(files1->d_name, "..")){
        continue;
          }
          if(x%5==0)
            printf("\n");
          printf("%s\t", files1->d_name);
          x++;
      }
      printf("\n");
      printf("\n");
      closedir(dir);
      return 0;
  }

  while((opt= getopt(argc,argv,"dl")) != -1){
    switch(opt){
      case 'd':{
        if(argc == 2){
            printf(".\n");
            continue;
            }
        return 0;
      }
      case 'l':{
        if(argc==3){
          count = scandir(argv[2], &files, tmp, alphasort);
          if(count<0){
            printf("Error getting path");
            exit(0);
          }
        }
        else{
          if(!getcwd(pathname, sizeof(pathname))){
              perror("Error getting path");
              exit(0);
          }
          count = scandir(pathname, &files, tmp, alphasort);
        }
        
        printf("total %d\n",count);
          for (i=0; i<count; ++i)
          { 
            if (stat(files[i]->d_name, &statbuf) == 0)
            {
            /* Print out type, permissions, and number of links. */
            printf("%10.10s", perms(statbuf.st_mode));
            printf(" %d", statbuf.st_nlink);

            if (!getpwuid_r(statbuf.st_uid, &pwent, buf, sizeof(buf), &pwentp))
              printf(" %s", pwent.pw_name);
            else
             printf(" %d", statbuf.st_uid);

            if (!getgrgid_r (statbuf.st_gid, &grp, buf, sizeof(buf), &grpt))
              printf(" %s", grp.gr_name);
            else
              printf(" %d", statbuf.st_gid);

            /* Print size of file. */
            printf(" %5d", (int)statbuf.st_size);

            localtime_r(&statbuf.st_mtime, &time);
            /* Get localized date string. */
            strftime(date, sizeof(date), "%F %T", &time);

            printf(" %s %s\n", date, files[i]->d_name);
            }
            free (files[i]); 
          }
          free(files);
          return 0;
      }    
      default:{}
    }
  }

  if(argc>1){    //If there are no options used on command prompt
  
      dir = opendir (argv[1]);
      int x = 0;
      while((files1 = readdir(dir)) != NULL){
          if(!strcmp(files1->d_name, ".") || !strcmp(files1->d_name, "..")){
        continue;
          }
          if(x%5==0)
            printf("\n");
          printf("%s\t", files1->d_name);
          x++;
      }
      printf("\n");
      printf("\n");
      closedir(dir);
      return 0;
  }



  return 0;
}

const char *perms(mode_t mode)
{
  char ftype = '?';

  if (S_ISREG(mode)) ftype = '-';
  if (S_ISLNK(mode)) ftype = 'l';
  if (S_ISDIR(mode)) ftype = 'd';
  if (S_ISBLK(mode)) ftype = 'b';
  if (S_ISCHR(mode)) ftype = 'c';
  if (S_ISFIFO(mode)) ftype = '|';


  sprintf(perms_buff, "%c%c%c%c%c%c%c%c%c%c %c%c%c", ftype,
  mode & S_IRUSR ? 'r' : '-',
  mode & S_IWUSR ? 'w' : '-',
  mode & S_IXUSR ? 'x' : '-',
  mode & S_IRGRP ? 'r' : '-',
  mode & S_IWGRP ? 'w' : '-',
  mode & S_IXGRP ? 'x' : '-',
  mode & S_IROTH ? 'r' : '-',
  mode & S_IWOTH ? 'w' : '-',
  mode & S_IXOTH ? 'x' : '-',
  mode & S_ISUID ? 'U' : '-',
  mode & S_ISGID ? 'G' : '-',
  mode & S_ISVTX ? 'S' : '-');

  return (const char *)perms_buff;
}

static int tmp (const struct dirent *unused)
{
  return 1;
}


