#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	pid_t child_pid = fork();

	if(child_pid > 0)
	{
		sleep(15); // Put the parent process to sleep for 15 seconds. 
		printf("Parent executing PS command\n");
		system("ps"); // After the sleep, have the parent call ps aux. A Zombie will show. 
	}
	else
	{
		printf("Child executing PS command\n");
		system("ps"); // Have the child execute the 1st PS command (Not a Zombie yet)
		exit(0); //Exit the child process while parent is sleeping to create a zombie. * Any lines past exit will not get executed * 	
	}

	return 0; 
}
