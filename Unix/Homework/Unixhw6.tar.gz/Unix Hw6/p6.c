#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]){

	int i = atoi(argv[1]);

	char messageSent[] = "Message has been passed.\n";
	char messageReceived [25];

	if(argc != 2)
	{
		perror("Did not enter number of processes to create.\n");
		exit(2);
	}

	for(int processes = 0; processes < i; processes++)
	{
		int fd[2], pid;

		pipe(fd);
		pid = fork();

		if (pid < 0){		//error
			perror("Error. \n");
			exit(2);
		}
		else if (!pid){		//child
			read(fd[0], &messageReceived, sizeof(messageReceived));
			printf("Message Received:  %s", messageReceived);
			printf("Child PID: %d\n", getpid());
			exit(0);
		}
		else{				//parent
			write(fd[1], messageSent, sizeof(messageSent));
			printf("Parent PID: %d\n", getpid());
		}
	}

	return EXIT_SUCCESS;
}


