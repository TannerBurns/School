#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main()
{
	int pid;
	int status;
	if((pid = fork()) == 0)
	{
		//sleep(1); // Used for a) result 2.
		sleep(1);
		wait(&status);
		printf("Child\n");
	}
	else if(pid > 0)
	{
		wait(&status);
		sleep(1);
		printf("Parent\n");
	}
	return 0;
}
