#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[])
{
	int numProcesses, pid, status, i;

	i = atoi(argv[1]); 

	if(argc != 2)
	{
		perror("Too Few Arguments Passed");
		exit(1);
	}

	for(numProcesses = 0; numProcesses < i; numProcesses++)
	{
		pid = fork();
		if(pid < 0)
		{
			perror("Error Forking Processes");
			exit(1);
		}
		else if(pid == 0)
		{
			printf("Child (%d): %d\n", numProcesses + 1, getpid());
			exit(0); // Maybe this needs to be moved. 
		}

	}

	for(numProcesses = 0; numProcesses < atoi(argv[1]); numProcesses++)
	{
		wait(&status);
	}

	return 0;
}