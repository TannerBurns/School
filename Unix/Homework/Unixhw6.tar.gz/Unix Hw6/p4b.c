#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main()
{
	int pid;
	int status;
	if((pid = fork()) == 0)
	{
		printf("Child\n");
	}
	else if(pid > 0)
	{
		printf("Parent\n");
		wait(&status); //Used for b) result 1.
	}
	return 0;
}
