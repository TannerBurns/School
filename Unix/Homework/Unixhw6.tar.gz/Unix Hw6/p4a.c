#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main()
{
	int pid;
	if((pid = fork()) == 0)
	{
		sleep(1); // Used for a) result 2.
		printf("Child\n");
	}
	else if(pid > 0)
	{
		
		printf("Parent\n");
	}
	return 0;
}
