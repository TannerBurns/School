#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int foo_system(const char *command);

int main(int argc, char *argv[], char *env[])
{
  pid_t my_pid, parent_pid, child_pid;
  int status, i;
  char command[256];
  char test[100];

  /* get and print my pid and my parent's pid. */
  my_pid = getpid();
  parent_pid = getppid();
  printf("Parent: my PID is: %d\n", my_pid);
  printf("Parent: my parent's PID is: %d\n", parent_pid);
  printf("Parent: I will now call the foo_system function which will fork a child process.\n\n");

  if(argc < 2)
  {
    perror("You passed too few arguments");
    exit(1);
  }

  strcpy(command, argv[1]);
  if(argc >= 3)
  {
    for(i = 2; i < argc; i++)
    {
      strcat(command, " ");
      strcat(command, argv[i]);
    }
  }

  foo_system(command);
  return 0;
}

int foo_system(const char *command)
{
  int status;
  pid_t child_pid, my_pid, parent_pid;

  if((child_pid = fork()) < 0) //Fork the child and check for errors.
  {
    perror("Unable to fork a child process");
    exit(1);
  }

  if(child_pid == 0) // Have the child process execute stuffs.
  {
    printf("Child: Child process created!\n");
    my_pid = getpid();
    parent_pid = getppid();
    printf("Child: My pid is: %d\n", my_pid);
    printf("Child: My parent's pid is: %d\n\n", parent_pid);
    //printf("Child: For security reasons I will now sleep for 3 seconds and then execute the passed command.\n\n");

    sleep(3);
    execl("/bin/sh", "sh", "-c", command, (char *)0);
  }
  else
  {
    wait(&status);
  }
  return 0;
}
