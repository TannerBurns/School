#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>

int main()
{
	int pid; 

	if((pid = fork()) == 0) // Fork a child immediately upon execution. 
	{
		sleep(10);
		printf("The child is executing PS\n");
		system("ps");
		if((pid = fork()) > 0) //Fork a grandchild and kill the original child. 
		{
			exit(0);
		}
		if(pid == 0)
		{
			//Grandchild. 
			sleep(3);
			printf("The grandchildchild is executing PS\n");
			system("ps");
			exit(0);
		}
	}
	else if(pid > 0)
	{
		//Code for parent here. 
		printf("The parent is execuing PS\n");
		system("ps");
	}
	
	return 0;
}