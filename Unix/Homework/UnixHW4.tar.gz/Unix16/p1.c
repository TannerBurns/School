#include <stdio.h>

int main(){
  FILE *fp;
	fp=fopen("test.txt","a+");
	int a = fgetc(fp);
	printf("%c\n",a);
	int x = 'x';
	fputc(x,fp);
	fclose(fp);
  return 0;
}
