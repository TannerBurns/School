#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
int main()
{
    char data[30];

    int fd = open("test4.txt", O_RDWR | O_APPEND);
    if(fd < 0)
   	 perror("The file failed to open");

     off_t initalPos = lseek(fd, 0, SEEK_CUR); // Save the inital positon of the file

    lseek(fd, 4, SEEK_SET); //Set the fd pos 4 bytes from inital pos
 
    if(read(fd, data, 4) < 0)
   	 perror("Failed to read");

    lseek(fd, 4, initalPos);
    lseek(fd, 4, SEEK_SET); //Set the fd pos 4 bytes from inital pos

    if(write(fd, "Winning", 7) != 7)
 
    perror("Failed to write to the file");

    return 0;
}
