#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
int eof(int);

int main(){
	int fd=open("test4.txt",O_RDWR);
	int test = eof(fd);
	if(test==1){
		printf("Found eof.\n");
	}
	else if(test==0){
		printf("Didn't find eof.\n");
	}
	close(fd);
	return 0;
}

int eof(int fd)
{
    char data[10];

    int initialPos = lseek(fd, 0, SEEK_CUR); //Save the inital positon of the file upon entering the function
    lseek(fd, 5, SEEK_CUR);

    if(read(fd,data,1) <= 0){//Try and read a byte of data.
    	lseek(fd,0,initialPos);
    	return 1; //return 1 for EOF
    } 	 
    else
    {
   	 lseek(fd, 0, initialPos); //Set the file positon back to the original.
   	 return 0;
    }  
}
