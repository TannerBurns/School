#include <stdio.h>
#include <unistd.h>

int main()
{
  char name[30];
  int ID;
  double weight;  
  double height; 
  char gender;  
  double avgWght = 0.0;
  double avgHght = 0.0;
  double numEntries; 

  //Open the input file for reading. 
  FILE *inputFile = fopen("test1.txt", "r");
  if(inputFile == NULL)
    perror("Failed to open the file specified"); 
  else //Skip the first line (# name:id:weight:height:gender)
  {
    do
      gender = fgetc(inputFile);
    while(gender != '\n');
  }

  
  while((fscanf(inputFile, "%[^:]: %d: %lf: %lf: %c", name, &ID, &weight, &height, &gender)) == 5)
  {
     
    /*printf("The name passed is: %s\n", name);
    printf("The ID passed is: %d\n", ID);
    printf("The Weight passed is: %lf\n", weight);
    printf("The Height passed is: %lf\n", height);
    printf("The Gender passed is: %c\n", gender);*/
    
    avgWght += weight;
    avgHght += height;
    numEntries++;

  }
  
  avgWght = (avgWght / numEntries);
  avgHght = (avgHght / numEntries);


  fprintf(stdout, "Average Weight is: %lf\n", avgWght);
  fprintf(stdout, "Average Height is: %lf\n", avgHght);



  return 0;
}