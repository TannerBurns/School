#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
 
int main(int argc, char *argv[])
{
    int index = 0;
    int options = 0;
    int long_index = 0;
    int aOptFlag = 0;
    int bOptFlag = 0;
    int cOptFlag = 0;
    char *bArg = NULL;
    char *cArg = NULL;
    char catch = NULL;

    if(argc < 2){
        printf("Program requires at least one arguement\n");
        return 1;
    }
 
    static struct option long_options[] =
    {
        {"a", no_argument,NULL,'a'},
        {"b",required_argument,NULL,'b'},
        {"c", required_argument, NULL, 'c'},
        {0, 0, 0, 0}
    };

    

    
    while(options != -1)
    {
        options = getopt_long(argc, argv, "ab:c:", long_options, &long_index);
        switch(options)
        {
            case 'a':
            aOptFlag = 1;
                break;
            case 'b':
            bOptFlag = 1;
            bArg = optarg;
                break;
            case 'c':
            cOptFlag = 1;
            printf("option c with value '%s' \n", optarg);
            cArg = optarg;
                break;
            case '?':
                //Get optlong prints an error message by default
                //Fill statements in here if opterr = 0;
            default:
            exit(EXIT_FAILURE);
        }
    }
 
    if(aOptFlag == 1 && bOptFlag == 1)
    {  
        printf("The A & B options can not be active at the same time \n");
        //print_usage();
        exit(EXIT_FAILURE);
    }

 
    for(index = optind; index < argc; index++)
        printf ("Non-option argument %s\n", argv[index]);
    return 0;}