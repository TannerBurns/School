#include <dirent.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
	DIR *dir;
	struct dirent *ent;
	char cwd[1024];
	getcwd(cwd, sizeof(cwd));
	printf("Current working dir: %s\n", cwd);
	if ((dir = opendir (cwd)) != NULL) {
  	/* print all the files and directories within directory */
	printf("Raw order:");
  	while ((ent = readdir (dir)) != NULL) {
    	printf ("%s\n", ent->d_name);
	}
	struct dirent **ant;
	int n=scandir(".", &ant, NULL, alphasort);
	if(n<0)
	perror("scandir");
	else{
	printf("Alpha order:");
	int b;
	for(b=0;b<n;b++){
		printf("%s\n",ant[b]->d_name);
		free(ant[b]);
	
	}
	free(ant);
  	}
  	closedir (dir);
	}else {
  		/* could not open directory */
  		perror ("");
  		return -1;//EXIT_FAILURE;
	}
}
