#include <stdio.h>
#include <stdlib.h>

static void foo(void)
{
 if (status == 'A'){
   FILE *fp = fopen("file1.txt", "ab+");
   fprintf(fp, "Exit Program Status A");
 }

 if (status == 'B'){
   FILE *fp = fopen("file2.txt", "ab+");
   fprintf(fp, "Exit Program Status B");
 }
}

int main()
{
 atexit(foo);

 return 0;
}

