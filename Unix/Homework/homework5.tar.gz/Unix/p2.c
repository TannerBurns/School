#include <stdio.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>

int main(int argc, char *argv[]) {
    struct stat buf;
    stat(argv[1],&buf);
    
    printf("iNode's device: %d\n", buf.st_dev);
    printf("iNode's number: %llu\n", buf.st_ino);
    printf("iNode's protection mode: %d\n", buf.st_mode);
    printf("Number of hard links: %d\n", buf.st_nlink);
    struct group *g;
    struct passwd *u;
    g = getgrgid(buf.st_gid);
    u = getpwuid(buf.st_uid);
    printf("User id: %u, %s\n", buf.st_uid, u->pw_name);
    printf("Group id: %u, %s\n", buf.st_gid, g->gr_name);
    printf("Device type: %d\n", buf.st_rdev);
    printf("File size(in bytes): %llu\n", buf.st_size);
    struct tm *tm;
    char buf1[200];
    time_t t = buf.st_atime;
    tm = localtime(&t);
    strftime(buf1, sizeof(buf1), "%d.%m.%Y %H:%M:%S", tm);
    printf("Last access: %ld, %s\n", buf.st_atime, buf1);
    t = buf.st_mtime;
    tm = localtime(&t);
    strftime(buf1, sizeof(buf1), "%d.%m.%Y %H:%M:%S", tm);
    printf("Last data modification: %ld, %s\n", buf.st_mtime, buf1);
    t = buf.st_ctime;
    tm = localtime(&t);
    strftime(buf1, sizeof(buf1), "%d.%m.%Y %H:%M:%S", tm);
    printf("Last file status change: %ld, %s\n", buf.st_ctime,buf1);
    printf("Optimal blocksize for I/O: %d\n", buf.st_blksize);
    printf("Blocks allocated: %lld\n", buf.st_blocks);
    printf("User defind flags: %u\n", buf.st_flags);
    printf("File generation number: %u\n", buf.st_gen);    
    printf("File size: %lld\n", buf.st_size);
    printf("Symbolic link: %d\n", S_ISLNK(buf.st_mode));
    printf("Dir: %d\n", S_ISDIR(buf.st_mode));
    printf("Reg: %d\n", S_ISREG(buf.st_mode));
    return 0;
}
