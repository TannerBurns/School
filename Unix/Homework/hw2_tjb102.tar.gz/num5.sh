#! /bin/bash
total=0
echo "Given: $@"
printf "Squared: "
for((i=1;i<=$#;i++))do
	eval arg=\$$i
	sqr=$((arg*arg))
	total=$((total+sqr))
	printf "$sqr "
done
echo " "
echo "Total: $total"

