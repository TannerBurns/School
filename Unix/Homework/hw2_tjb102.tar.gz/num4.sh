#! /bin/bash
cd ~/Desktop
gcc -o num4 input1.c
if [ $? = '0' ]
then
	echo "Program ran"
	./num4
else
	echo "Program did not run"
fi	