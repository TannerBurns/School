#! /bin/bash

if [ "$#" -lt "1" ]
then
	echo "Must give a directory to start program"
	read -p ">" inp1
fi
for((i=1;i<=$#;i++))do
	eval arg=\$$i
	inp1=$arg
	cd "$inp1" > /dev/null 2>&1
		if [ "$?" = "0" ]
		then
			echo "Directory found, opening: $inp1"
		else
		while [ "$?" != "0" ]
		do
			echo "Directory not found, please enter valid directory or control+C to quit"
			read -p ">" inp1
			cd "$inp1" > /dev/null 2>&1
		done
		if [ "$?" = "0" ]
		then
			echo "Directory found, opening: $inp1"
		fi
	fi
	echo " "
	echo "Empty files(0 length files): "
	find "$inp1" -size 0 -print
	echo " "
	echo "Hidden files starting with '.': "
	ls "$inp1" -a | egrep '^\.'
done
